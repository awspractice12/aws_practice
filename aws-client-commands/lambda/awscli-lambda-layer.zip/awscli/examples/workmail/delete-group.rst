**To delete an existing group**

The following ``delete-group`` command deletes an existing group from Amazon WorkMail. ::

    aws workmail delete-group \
        --organization-id m-d281d0a2fd824be5b6cd3d3ce909fd27 \
        --group-id S-1-1-11-1122222222-2222233333-3333334444-4444

This command produces no output.
