**To reset a user's password**

The following ``reset-password`` command resets the password for the specified user. ::

    aws workmail reset-password \
        --organization-id m-d281d0a2fd824be5b6cd3d3ce909fd27 \
        --user-id S-1-1-11-1111111111-2222222222-3333333333-3333 \
        --password examplePa$$w0rd

This command produces no output.
