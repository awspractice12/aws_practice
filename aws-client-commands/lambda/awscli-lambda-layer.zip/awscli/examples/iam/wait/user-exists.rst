**To pause running until the specified user exists**

The following ``wait user-exists`` command pauses and continues only after it can confirm that the specified user exists. There is no output. ::

  aws iam wait user-exists --user-name marcia
